<div class="pd-page-title">Ubah Peminjaman Buku</div>
<div class="pd-page-sub">Perbarui status atau tanggal peminjaman.</div>
<div class="card">
    <div class="card-body">
        <?php
        $id = intval($_GET['id']);
        if (isset($_POST['submit'])) {
            $id_buku = intval($_POST['id_buku']);
            $tanggal_peminjaman = $_POST['tanggal_peminjaman'];
            $tanggal_pengembalian = $_POST['tanggal_pengembalian'];
            $status_peminjaman = mysqli_real_escape_string($koneksi, $_POST['status_peminjaman']);

            $query = mysqli_query($koneksi, "UPDATE peminjaman SET id_buku='$id_buku', tanggal_peminjaman='$tanggal_peminjaman', tanggal_pengembalian='$tanggal_pengembalian', status_peminjaman='$status_peminjaman' WHERE id_peminjaman='$id'");
            if ($query) {
                echo '<script>alert("Ubah peminjaman berhasil!"); location.href="?page=peminjaman";</script>';
            }
        }

        $q = mysqli_query($koneksi, "SELECT * FROM peminjaman WHERE id_peminjaman='$id'");
        $data = mysqli_fetch_array($q);
        ?>
        <form method="post">
            <div class="pd-form-row" style="max-width:480px;">
                <label class="pd-form-label">Buku</label>
                <select name="id_buku" class="form-select" required>
                    <?php
                    $b = mysqli_query($koneksi, "SELECT * FROM buku");
                    while ($book = mysqli_fetch_array($b)) {
                        $sel = ($data['id_buku'] == $book['id_buku']) ? 'selected' : '';
                        echo '<option value="' . $book['id_buku'] . '" ' . $sel . '>' . htmlspecialchars($book['judul']) . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="row">
                <div class="col-md-6 pd-form-row">
                    <label class="pd-form-label">Tanggal Pinjam</label>
                    <input type="date" class="form-control" name="tanggal_peminjaman" value="<?php echo htmlspecialchars($data['tanggal_peminjaman']); ?>" required>
                </div>
                <div class="col-md-6 pd-form-row">
                    <label class="pd-form-label">Tanggal Kembali</label>
                    <input type="date" class="form-control" name="tanggal_pengembalian" value="<?php echo htmlspecialchars($data['tanggal_pengembalian']); ?>" required>
                </div>
            </div>
            <div class="pd-form-row" style="max-width:300px;">
                <label class="pd-form-label">Status</label>
                <select name="status_peminjaman" class="form-select" required>
                    <option value="dipinjam" <?php echo ($data['status_peminjaman'] == 'dipinjam') ? 'selected' : ''; ?>>Dipinjam</option>
                    <option value="dikembalikan" <?php echo ($data['status_peminjaman'] == 'dikembalikan') ? 'selected' : ''; ?>>Dikembalikan</option>
                </select>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
                <a href="?page=peminjaman" class="btn btn-danger">Kembali</a>
            </div>
        </form>
    </div>
</div>
