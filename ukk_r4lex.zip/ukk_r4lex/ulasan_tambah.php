<div class="pd-page-title">Tambah Ulasan Buku</div>
<div class="pd-page-sub">Bagikan pendapatmu tentang buku yang sudah dibaca.</div>
<div class="card">
    <div class="card-body">
        <?php
        if (isset($_POST['submit'])) {
            $id_buku = intval($_POST['id_buku']);
            $id_user = intval($_SESSION['user']['id_user']);
            $ulasan = mysqli_real_escape_string($koneksi, $_POST['ulasan']);
            $rating = intval($_POST['rating']);

            $query = mysqli_query($koneksi, "INSERT INTO ulasan(id_buku, id_user, ulasan, rating) VALUES('$id_buku', '$id_user', '$ulasan', '$rating')");
            if ($query) {
                echo '<script>alert("Tambah ulasan berhasil!"); location.href="?page=ulasan";</script>';
            }
        }
        ?>
        <form method="post">
            <div class="pd-form-row" style="max-width:480px;">
                <label class="pd-form-label">Buku</label>
                <select name="id_buku" class="form-select" required>
                    <?php
                    $b = mysqli_query($koneksi, "SELECT * FROM buku");
                    while ($book = mysqli_fetch_array($b)) {
                        echo '<option value="' . $book['id_buku'] . '">' . htmlspecialchars($book['judul']) . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="pd-form-row">
                <label class="pd-form-label">Ulasan</label>
                <textarea name="ulasan" rows="4" class="form-control" required></textarea>
            </div>
            <div class="pd-form-row" style="max-width:220px;">
                <label class="pd-form-label">Rating (1-10)</label>
                <select name="rating" class="form-select">
                    <?php for ($i = 1; $i <= 10; $i++) { echo "<option value='$i'>$i</option>"; } ?>
                </select>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
                <a href="?page=ulasan" class="btn btn-danger">Kembali</a>
            </div>
        </form>
    </div>
</div>
