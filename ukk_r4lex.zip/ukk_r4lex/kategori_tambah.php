<div class="pd-page-title">Tambah Kategori Buku</div>
<div class="pd-page-sub">Lengkapi form berikut untuk menambah kategori baru.</div>
<div class="card">
    <div class="card-body">
        <?php
        if (isset($_POST['submit'])) {
            $kategori = mysqli_real_escape_string($koneksi, $_POST['kategori']);
            $query = mysqli_query($koneksi, "INSERT INTO kategori(kategori) VALUES('$kategori')");
            if ($query) {
                echo '<script>alert("Tambah data berhasil!"); location.href="?page=kategori";</script>';
            } else {
                echo '<script>alert("Tambah data gagal!");</script>';
            }
        }
        ?>
        <form method="post">
            <div class="pd-form-row" style="max-width:480px;">
                <label class="pd-form-label">Nama Kategori</label>
                <input type="text" class="form-control" name="kategori" required>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary" name="submit" value="submit">Simpan</button>
                <button type="reset" class="btn btn-secondary">Reset</button>
                <a href="?page=kategori" class="btn btn-danger">Kembali</a>
            </div>
        </form>
    </div>
</div>
