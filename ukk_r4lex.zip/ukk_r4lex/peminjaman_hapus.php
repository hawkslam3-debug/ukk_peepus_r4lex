<?php
$id = $_GET['id'];
$query = mysqli_query($koneksi, "DELETE FROM peminjaman WHERE id_peminjaman='$id'");
if ($query) {
    echo '<script>alert("Hapus data berhasil!"); location.href="?page=peminjaman";</script>';
}
?>