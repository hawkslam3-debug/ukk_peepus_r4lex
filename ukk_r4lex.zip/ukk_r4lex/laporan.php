<div class="pd-page-head">
    <div>
        <div class="pd-page-title">Laporan Peminjaman Buku</div>
        <div class="pd-page-sub">Rekap seluruh transaksi peminjaman buku.</div>
    </div>
    <a href="cetak.php" target="_blank" class="btn btn-primary"><i class="fa fa-print me-1"></i> Cetak Laporan</a>
</div>
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
        <table class="table" width="100%">
            <tr>
                <th>No</th>
                <th>User</th>
                <th>Buku</th>
                <th>Tanggal Pinjam</th>
                <th>Tanggal Kembali</th>
                <th>Status</th>
            </tr>
            <?php
            $i = 1;
            $query = mysqli_query($koneksi, "SELECT * FROM peminjaman LEFT JOIN user ON user.id_user = peminjaman.id_user LEFT JOIN buku ON buku.id_buku = peminjaman.id_buku");
            while ($data = mysqli_fetch_array($query)) {
            ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo htmlspecialchars($data['nama']); ?></td>
                    <td class="fw-semibold"><?php echo htmlspecialchars($data['judul']); ?></td>
                    <td><?php echo htmlspecialchars($data['tanggal_peminjaman']); ?></td>
                    <td><?php echo htmlspecialchars($data['tanggal_pengembalian']); ?></td>
                    <td>
                        <?php if ($data['status_peminjaman'] == 'dikembalikan') { ?>
                            <span class="pd-badge pd-badge-green">Dikembalikan</span>
                        <?php } else { ?>
                            <span class="pd-badge pd-badge-orange">Dipinjam</span>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
        </div>
    </div>
</div>
