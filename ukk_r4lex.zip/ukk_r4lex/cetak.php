<?php
include "koneksi.php";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <title>Laporan Peminjaman Buku</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@400;600;700&family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Chakra Petch', Arial, sans-serif; color: #10203F; padding: 28px; }
        h2 { text-align: center; color: #06263B; margin-bottom: 4px; letter-spacing: 0.02em; }
        p.sub { text-align: center; color: #5B6C92; margin-top: 0; margin-bottom: 22px;
                font-family: 'Share Tech Mono', monospace; font-size: 0.8rem; letter-spacing: 0.1em; }
        .rule { height: 3px; background: linear-gradient(90deg, #0090A8, #D6156A); margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #C9D6EC; padding: 8px 10px; font-size: 0.85rem; text-align: left; }
        th { background: #E6F6F9; color: #00707F; text-transform: uppercase;
             font-family: 'Share Tech Mono', monospace; font-size: 0.72rem; letter-spacing: 0.1em; }
        tr:nth-child(even) td { background: #F5F9FF; }
    </style>
</head>
<body>
    <h2>Laporan Peminjaman Buku</h2>
    <p class="sub">PUSTAKA DIGITAL &middot; DICETAK <?php echo strtoupper(date('d M Y')); ?></p>
    <div class="rule"></div>
    <table cellspacing="0" cellpadding="5">
        <tr>
            <th>No</th>
            <th>User</th>
            <th>Buku</th>
            <th>Tanggal Pinjam</th>
            <th>Tanggal Kembali</th>
            <th>Status Peminjaman</th>
        </tr>
        <?php
        $i = 1;
        $query = mysqli_query($koneksi, "SELECT * FROM peminjaman LEFT JOIN user ON user.id_user = peminjaman.id_user LEFT JOIN buku ON buku.id_buku = peminjaman.id_buku");
        while ($data = mysqli_fetch_array($query)) {
        ?>
            <tr>
                <td><?php echo $i++; ?></td>
                <td><?php echo htmlspecialchars($data['nama']); ?></td>
                <td><?php echo htmlspecialchars($data['judul']); ?></td>
                <td><?php echo htmlspecialchars($data['tanggal_peminjaman']); ?></td>
                <td><?php echo htmlspecialchars($data['tanggal_pengembalian']); ?></td>
                <td><?php echo htmlspecialchars($data['status_peminjaman']); ?></td>
            </tr>
        <?php } ?>
    </table>

    <script>
        window.print();
        setTimeout(function() {
            window.close();
        }, 100);
    </script>
</body>
</html>
