<div class="pd-page-head">
    <div>
        <div class="pd-page-title">Ulasan Buku</div>
        <div class="pd-page-sub">Ulasan dan penilaian dari pembaca.</div>
    </div>
    <a href="?page=ulasan_tambah" class="btn btn-primary"><i class="fas fa-plus me-1"></i> Tambah Ulasan</a>
</div>
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
        <table class="table" width="100%">
            <tr>
                <th>No</th>
                <th>User</th>
                <th>Buku</th>
                <th>Ulasan</th>
                <th>Rating</th>
                <th class="text-end pe-4">Aksi</th>
            </tr>
            <?php
            $i = 1;
            $query = mysqli_query($koneksi, "SELECT * FROM ulasan LEFT JOIN user ON user.id_user = ulasan.id_user LEFT JOIN buku ON buku.id_buku = ulasan.id_buku");
            while ($data = mysqli_fetch_array($query)) {
            ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo htmlspecialchars($data['nama']); ?></td>
                    <td class="fw-semibold"><?php echo htmlspecialchars($data['judul']); ?></td>
                    <td style="max-width:260px;" class="text-truncate"><?php echo htmlspecialchars($data['ulasan']); ?></td>
                    <td><span class="pd-badge pd-badge-orange"><i class="fas fa-star me-1"></i><?php echo htmlspecialchars($data['rating']); ?>/10</span></td>
                    <td class="text-end pe-4 text-nowrap">
                        <a href="?page=ulasan_ubah&id=<?php echo $data['id_ulasan']; ?>" class="btn btn-info btn-sm">Ubah</a>
                        <a onclick="return confirm('Hapus ulasan ini?');" href="?page=ulasan_hapus&id=<?php echo $data['id_ulasan']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
        </div>
    </div>
</div>
