<?php
$id = intval($_GET['id'] ?? 0);

$cekPakai = mysqli_query($koneksi, "SELECT COUNT(*) AS jumlah FROM buku WHERE id_kategori='$id'");
$jumlahBuku = mysqli_fetch_assoc($cekPakai)['jumlah'];

if ($jumlahBuku > 0) {
    echo '<script>alert("Kategori tidak bisa dihapus karena masih dipakai oleh ' . $jumlahBuku . ' buku. Ubah atau hapus buku tersebut terlebih dahulu."); location.href="?page=kategori";</script>';
    exit;
}

$query = mysqli_query($koneksi, "DELETE FROM kategori WHERE id_kategori='$id'");
if ($query) {
    echo '<script>alert("Hapus data berhasil!"); location.href="?page=kategori";</script>';
} else {
    echo '<script>alert("Gagal menghapus data: ' . addslashes(mysqli_error($koneksi)) . '"); location.href="?page=kategori";</script>';
}
?>