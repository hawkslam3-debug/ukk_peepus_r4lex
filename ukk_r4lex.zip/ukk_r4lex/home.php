<div class="pd-banner">
    <h2>Halo, <?php echo htmlspecialchars($_SESSION['user']['nama']); ?></h2>
    <p>Kelola koleksi buku, pantau peminjaman, dan baca ulasan terbaru dari satu dashboard.</p>
    <div class="pd-ticker" aria-hidden="true">
        <span>
            SESI AKTIF &middot; LEVEL <?php echo strtoupper(htmlspecialchars($_SESSION['user']['level'])); ?> &middot; <?php echo strtoupper(date('d M Y')); ?> &middot; KONEKSI ARSIP STABIL &middot; INDEKS KATALOG TERBARU &middot;&nbsp;
            SESI AKTIF &middot; LEVEL <?php echo strtoupper(htmlspecialchars($_SESSION['user']['level'])); ?> &middot; <?php echo strtoupper(date('d M Y')); ?> &middot; KONEKSI ARSIP STABIL &middot; INDEKS KATALOG TERBARU &middot;&nbsp;
        </span>
    </div>
</div>

<div class="row g-3 mb-2">
    <div class="col-6 col-xl-3">
        <div class="pd-stat-card pd-stat-purple">
            <div class="pd-stat-icon"><i class="fas fa-tags"></i></div>
            <div class="pd-stat-value"><?php echo mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM kategori")); ?></div>
            <div class="pd-stat-label">Total Kategori</div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="pd-stat-card pd-stat-orange">
            <div class="pd-stat-icon"><i class="fas fa-book"></i></div>
            <div class="pd-stat-value"><?php echo mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM buku")); ?></div>
            <div class="pd-stat-label">Total Buku</div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="pd-stat-card pd-stat-green">
            <div class="pd-stat-icon"><i class="fas fa-comment"></i></div>
            <div class="pd-stat-value"><?php echo mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM ulasan")); ?></div>
            <div class="pd-stat-label">Total Ulasan</div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="pd-stat-card pd-stat-pink">
            <div class="pd-stat-icon"><i class="fas fa-users"></i></div>
            <div class="pd-stat-value"><?php echo mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM user")); ?></div>
            <div class="pd-stat-label">Total User</div>
        </div>
    </div>
</div>

<div class="card mt-3">
    <div class="card-header">Informasi Akun</div>
    <div class="card-body">
        <table class="table" width="100%">
            <tr>
                <td width="200" class="text-muted">Nama User</td>
                <td width="1">:</td>
                <td class="fw-semibold"><?php echo htmlspecialchars($_SESSION['user']['nama']); ?></td>
            </tr>
            <tr>
                <td width="200" class="text-muted">Level Hak Akses</td>
                <td width="1">:</td>
                <td><span class="pd-badge pd-badge-purple"><?php echo htmlspecialchars($_SESSION['user']['level']); ?></span></td>
            </tr>
            <tr>
                <td width="200" class="text-muted">Tanggal Login</td>
                <td width="1">:</td>
                <td class="fw-semibold"><?php echo date('d-m-Y'); ?></td>
            </tr>
        </table>
    </div>
</div>
