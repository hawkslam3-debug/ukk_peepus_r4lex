<?php
include "koneksi.php";

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

$page = isset($_GET['page']) ? $_GET['page'] : 'home';
$menuMap = [
    'home' => 'home',
    'kategori' => 'kategori',
    'kategori_tambah' => 'kategori',
    'kategori_ubah' => 'kategori',
    'buku' => 'buku',
    'buku_tambah' => 'buku',
    'buku_ubah' => 'buku',
    'peminjaman' => 'peminjaman',
    'peminjaman_tambah' => 'peminjaman',
    'peminjaman_ubah' => 'peminjaman',
    'ulasan' => 'ulasan',
    'ulasan_tambah' => 'ulasan',
    'ulasan_ubah' => 'ulasan',
    'laporan' => 'laporan',
];
$activeMenu = isset($menuMap[$page]) ? $menuMap[$page] : $page;
$namaUser = $_SESSION['user']['nama'];
$initial = strtoupper(substr($namaUser, 0, 1));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Pustaka Digital</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@400;500;600;700&family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <link href="css/theme.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <script>
        // Pasang tema sedini mungkin supaya tidak ada kedipan warna saat halaman dimuat.
        (function () {
            var t = localStorage.getItem('pd-theme') || 'dark';
            document.documentElement.classList.add(t === 'light' ? 'pd-pre-light' : 'pd-pre-dark');
            document.addEventListener('DOMContentLoaded', function () {
                document.body.classList.add(t === 'light' ? 'pd-light' : 'pd-dark');
            });
        })();
    </script>
</head>
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand">
        <a class="navbar-brand ps-1" href="index.php"><span class="pd-brand-text" data-text="Pustaka Digital">Pustaka Digital</span></a>
        <button class="btn btn-link order-1 order-lg-0 me-3 me-lg-3" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <div class="pd-topbar-search">
            <i class="fas fa-search"></i>
            <input type="text" id="pdSearchInput" placeholder="Cari di tabel halaman ini...">
        </div>
        <div class="pd-topbar-actions">
            <button type="button" class="pd-icon-btn pd-has-dot" aria-label="Notifikasi"><i class="fas fa-bell"></i></button>
            <button type="button" class="pd-icon-btn" id="themeToggleBtn" title="Ganti tema gelap/terang" aria-label="Ganti tema gelap/terang"><i class="fas fa-sun" id="themeToggleIcon"></i></button>
            <div class="pd-topbar-userinfo">
                <span class="name"><?php echo htmlspecialchars($namaUser); ?></span>
                <span class="role"><?php echo htmlspecialchars($_SESSION['user']['level']); ?></span>
            </div>
            <div class="pd-avatar"><?php echo htmlspecialchars($initial); ?></div>
        </div>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-light" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Navigasi</div>
                        <a class="nav-link<?php echo $activeMenu === 'home' ? ' active' : ''; ?>" href="?">
                            <div class="sb-nav-link-icon"><i class="fas fa-house"></i></div>
                            Dashboard
                        </a>

                        <?php if ($_SESSION['user']['level'] != 'peminjam') { ?>
                            <a class="nav-link<?php echo $activeMenu === 'kategori' ? ' active' : ''; ?>" href="?page=kategori">
                                <div class="sb-nav-link-icon"><i class="fas fa-tags"></i></div>
                                Kategori
                            </a>
                            <a class="nav-link<?php echo $activeMenu === 'buku' ? ' active' : ''; ?>" href="?page=buku">
                                <div class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
                                Buku
                            </a>
                        <?php } else { ?>
                            <a class="nav-link<?php echo $activeMenu === 'peminjaman' ? ' active' : ''; ?>" href="?page=peminjaman">
                                <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                Peminjaman
                            </a>
                        <?php } ?>

                        <a class="nav-link<?php echo $activeMenu === 'ulasan' ? ' active' : ''; ?>" href="?page=ulasan">
                            <div class="sb-nav-link-icon"><i class="fas fa-comment"></i></div>
                            Ulasan
                        </a>

                        <?php if ($_SESSION['user']['level'] != 'peminjam') { ?>
                            <a class="nav-link<?php echo $activeMenu === 'laporan' ? ' active' : ''; ?>" href="?page=laporan">
                                <div class="sb-nav-link-icon"><i class="fas fa-file-lines"></i></div>
                                Laporan Peminjaman
                            </a>
                        <?php } ?>

                        <a class="nav-link" href="logout.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-power-off"></i></div>
                            Logout
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="pd-mascot pd-sidebar-mascot">
                        <img src="assets/img/mascot-nyx.svg" alt="NYX, maskot operator arsip" />
                    </div>
                    <div class="small">Masuk sebagai</div>
                    <div class="fw-semibold"><?php echo htmlspecialchars($namaUser); ?></div>
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <?php
                    if (preg_match('/^[a-zA-Z_]+$/', $page) && file_exists($page . '.php')) {
                        include $page . '.php';
                    } else {
                        include '404.php';
                    }
                    ?>
                </div>
            </main>
            <footer class="py-4 mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">R4LEX FOR LOLY &copy; <?php echo date('Y'); ?></div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <div class="pd-mascot-dock" aria-hidden="true">
        <div class="pd-mascot-bubble"></div>
        <div class="pd-mascot">
            <img src="assets/img/mascot-nyx.svg" alt="" />
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="js/theme.js"></script>
</body>
</html>
