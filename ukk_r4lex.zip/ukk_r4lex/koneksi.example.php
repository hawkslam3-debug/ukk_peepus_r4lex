<?php
/**
 * Contoh konfigurasi koneksi database.
 *
 * Cara pakai:
 *   1. Duplikat/copy file ini menjadi "koneksi.php" (di folder yang sama).
 *   2. Sesuaikan HOST, USERNAME, PASSWORD, dan NAMA_DATABASE di bawah
 *      dengan konfigurasi MySQL/MariaDB di komputer/server kamu.
 *   3. File "koneksi.php" sudah masuk .gitignore, jadi kredensial asli
 *      tidak akan ikut ter-commit ke Git.
 */

session_start();

$koneksi = mysqli_connect(
    "localhost",        // Host database (biasanya "localhost" saat development)
    "root",             // Username database
    "",                 // Password database (kosongkan jika default XAMPP/Laragon)
    "library_lendraw"   // Nama database
);

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
