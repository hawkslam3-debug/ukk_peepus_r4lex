<?php
$id = intval($_GET['id'] ?? 0);

$cekPinjam = mysqli_query($koneksi, "SELECT COUNT(*) AS jumlah FROM peminjaman WHERE id_buku='$id'");
$jumlahPinjam = mysqli_fetch_assoc($cekPinjam)['jumlah'];

$cekUlasan = mysqli_query($koneksi, "SELECT COUNT(*) AS jumlah FROM ulasan WHERE id_buku='$id'");
$jumlahUlasan = mysqli_fetch_assoc($cekUlasan)['jumlah'];

if ($jumlahPinjam > 0 || $jumlahUlasan > 0) {
    $alasan = [];
    if ($jumlahPinjam > 0) { $alasan[] = $jumlahPinjam . ' data peminjaman'; }
    if ($jumlahUlasan > 0) { $alasan[] = $jumlahUlasan . ' ulasan'; }
    $pesan = 'Buku tidak bisa dihapus karena masih terkait dengan ' . implode(' dan ', $alasan) . '. Hapus data tersebut terlebih dahulu.';
    echo '<script>alert("' . $pesan . '"); location.href="?page=buku";</script>';
    exit;
}

$query = mysqli_query($koneksi, "DELETE FROM buku WHERE id_buku='$id'");
if ($query) {
    echo '<script>alert("Hapus data berhasil!"); location.href="?page=buku";</script>';
} else {
    echo '<script>alert("Gagal menghapus data: ' . addslashes(mysqli_error($koneksi)) . '"); location.href="?page=buku";</script>';
}
?>