<div class="pd-page-head">
    <div>
        <div class="pd-page-title">Kategori Buku</div>
        <div class="pd-page-sub">Kelola kategori untuk mengelompokkan koleksi buku.</div>
    </div>
    <a href="?page=kategori_tambah" class="btn btn-primary"><i class="fas fa-plus me-1"></i> Tambah Data</a>
</div>
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
        <table class="table" width="100%" cellspacing="0">
            <tr>
                <th>No</th>
                <th>Nama Kategori</th>
                <th class="text-end pe-4">Aksi</th>
            </tr>
            <?php
            $i = 1;
            $query = mysqli_query($koneksi, "SELECT * FROM kategori");
            while ($data = mysqli_fetch_array($query)) {
            ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td class="fw-semibold"><?php echo htmlspecialchars($data['kategori']); ?></td>
                    <td class="text-end pe-4">
                        <a href="?page=kategori_ubah&id=<?php echo $data['id_kategori']; ?>" class="btn btn-info btn-sm">Ubah</a>
                        <a onclick="return confirm('Apakah Anda yakin menghapus data ini?');" href="?page=kategori_hapus&id=<?php echo $data['id_kategori']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
        </div>
    </div>
</div>
