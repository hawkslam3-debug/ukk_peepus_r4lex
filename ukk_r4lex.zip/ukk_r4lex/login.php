<?php
include "koneksi.php";

$error = '';

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = mysqli_prepare($koneksi, "SELECT * FROM user WHERE username = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user) {
        $storedHash = $user['password'];
        $passwordOk = false;

        // Support both new password_hash() values and legacy md5() values,
        // upgrading legacy hashes to password_hash() automatically on login.
        if (password_verify($password, $storedHash)) {
            $passwordOk = true;
        } elseif ($storedHash === md5($password)) {
            $passwordOk = true;
            $newHash = password_hash($password, PASSWORD_DEFAULT);
            $upd = mysqli_prepare($koneksi, "UPDATE user SET password = ? WHERE id_user = ?");
            mysqli_stmt_bind_param($upd, "si", $newHash, $user['id_user']);
            mysqli_stmt_execute($upd);
            $user['password'] = $newHash;
        }

        if ($passwordOk) {
            unset($user['password']);
            $_SESSION['user'] = $user;
            header('Location: index.php');
            exit();
        }
    }

    $error = 'Username atau password salah.';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Login - Pustaka Digital</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@400;500;600;700&family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet" />
    <link href="css/theme.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <script>
        // Pasang tema sedini mungkin supaya tidak ada kedipan warna saat halaman dimuat.
        (function () {
            var t = localStorage.getItem('pd-theme') || 'dark';
            document.documentElement.classList.add(t === 'light' ? 'pd-pre-light' : 'pd-pre-dark');
            document.addEventListener('DOMContentLoaded', function () {
                document.body.classList.add(t === 'light' ? 'pd-light' : 'pd-dark');
            });
        })();
    </script>
</head>
<body>
    <div class="pd-auth-wrap">
        <div class="pd-auth-card">
            <div class="pd-auth-visual">
                <div class="pd-auth-icon"><i class="fas fa-book-open"></i></div>
                <h2>Neo Archive<br>Pustaka Digital</h2>
                <p>Jelajahi koleksi buku, pinjam dengan mudah, dan pantau riwayat bacaanmu dari satu terminal.</p>
                <div class="pd-auth-meta">Terminal siap &middot; Masukkan kredensial untuk masuk</div>
                <div class="pd-mascot pd-auth-mascot">
                    <img src="assets/img/mascot-nyx.svg" alt="NYX, maskot operator arsip" />
                </div>
            </div>
            <div class="pd-auth-form">
                <h3>Masuk</h3>
                <div class="pd-auth-sub">Akses terminal</div>

                <?php if ($error) { ?>
                    <div class="pd-auth-error"><?php echo htmlspecialchars($error); ?></div>
                <?php } ?>

                <form method="post">
                    <div class="pd-form-row">
                        <label class="pd-form-label">Username</label>
                        <input class="form-control" name="username" type="text" placeholder="Masukkan username" required autofocus />
                    </div>
                    <div class="pd-form-row">
                        <label class="pd-form-label">Password</label>
                        <input class="form-control" name="password" type="password" placeholder="Masukkan password" required />
                    </div>
                    <button class="btn btn-primary w-100 mt-2" type="submit" name="login" value="login">Masuk</button>
                </form>
                <div class="text-center mt-3" style="font-size:0.88rem;color:var(--pd-text-muted);">
                    Belum punya akun? <a href="register.php" style="color:var(--pd-cyan);font-weight:600;">Daftar di sini</a>
                </div>
            </div>
        </div>
    </div>
    <script src="js/theme.js"></script>
</body>
</html>
