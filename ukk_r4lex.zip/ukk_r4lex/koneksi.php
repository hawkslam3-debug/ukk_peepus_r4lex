<?php
session_start();
$koneksi = mysqli_connect("localhost", "root", "", "library_r4lex", 3307);

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>