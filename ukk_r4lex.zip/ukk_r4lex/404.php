<div class="pd-404">
    <div class="pd-404-code" data-text="404">404</div>
    <div class="pd-page-title">Halaman tidak ditemukan</div>
    <p class="pd-page-sub">Alamat yang diminta tidak ada di arsip. Periksa kembali tautannya, atau kembali ke dashboard.</p>
    <a href="index.php" class="btn btn-primary">Kembali ke dashboard</a>
</div>
