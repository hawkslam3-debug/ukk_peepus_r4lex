/* =========================================================================
   Pustaka Digital — NEO ARCHIVE
   Pencarian tabel live, pergantian tema, dan animasi antarmuka.
   ========================================================================= */
(function () {
  'use strict';

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* --------------------------------------------------------------------
     Tema: gelap (default) <-> terang. Disimpan di localStorage.
     Kelas pd-light dipasang di <body>; pd-dark tetap didukung agar
     halaman lama tidak rusak.
     -------------------------------------------------------------------- */
  function applyTheme(theme) {
    var body = document.body;
    var icon = document.getElementById('themeToggleIcon');
    var btn = document.getElementById('themeToggleBtn');
    var light = theme === 'light';

    body.classList.toggle('pd-light', light);
    body.classList.toggle('pd-dark', !light);

    if (icon) {
      icon.classList.toggle('fa-sun', !light);
      icon.classList.toggle('fa-moon', light);
    }
    if (btn) {
      btn.classList.toggle('active', light);
      btn.setAttribute('aria-label', light ? 'Ganti ke mode gelap' : 'Ganti ke mode terang');
    }
  }
  window.pdApplyTheme = applyTheme;

  window.addEventListener('DOMContentLoaded', function () {

    applyTheme(localStorage.getItem('pd-theme') || 'dark');

    var themeBtn = document.getElementById('themeToggleBtn');
    if (themeBtn) {
      themeBtn.addEventListener('click', function () {
        var next = document.body.classList.contains('pd-light') ? 'dark' : 'light';
        localStorage.setItem('pd-theme', next);
        applyTheme(next);
      });
    }

    /* ----------------------------------------------------------------
       Lapisan efek latar (grid, scanline, glow) — disisipkan lewat JS
       supaya tidak perlu menambah markup di tiap halaman.
       ---------------------------------------------------------------- */
    if (!document.querySelector('.pd-fx')) {
      var fx = document.createElement('div');
      fx.className = 'pd-fx';
      fx.setAttribute('aria-hidden', 'true');
      fx.innerHTML = '<div class="pd-fx-glow"></div><div class="pd-fx-grid"></div>';
      document.body.insertBefore(fx, document.body.firstChild);

      if (!reduceMotion) {
        var fxTop = document.createElement('div');
        fxTop.className = 'pd-fx-top';
        fxTop.setAttribute('aria-hidden', 'true');
        fxTop.innerHTML = '<div class="pd-fx-beam"></div><div class="pd-fx-scan"></div>';
        document.body.appendChild(fxTop);
      }
    }

    if (!reduceMotion) {
      var bar = document.createElement('div');
      bar.className = 'pd-loadbar';
      bar.setAttribute('aria-hidden', 'true');
      document.body.appendChild(bar);
      setTimeout(function () { bar.remove(); }, 1400);
    }

    /* ----------------------------------------------------------------
       Glitch berkala pada wordmark
       ---------------------------------------------------------------- */
    var brand = document.querySelector('.pd-brand-text');
    if (brand) {
      if (!brand.getAttribute('data-text')) {
        brand.setAttribute('data-text', brand.textContent.trim());
      }
      if (!reduceMotion) {
        setInterval(function () {
          brand.classList.add('is-glitching');
          setTimeout(function () { brand.classList.remove('is-glitching'); }, 900);
        }, 9000);
      }
    }

    /* ----------------------------------------------------------------
       Animasi masuk bertahap untuk kartu & baris tabel
       ---------------------------------------------------------------- */
    var targets = document.querySelectorAll(
      '#layoutSidenav_content .pd-banner, #layoutSidenav_content .pd-stat-card, ' +
      '#layoutSidenav_content .card, #layoutSidenav_content .pd-page-head'
    );

    if (reduceMotion || !('IntersectionObserver' in window)) {
      targets.forEach(function (el) { el.classList.add('is-in'); });
    } else {
      targets.forEach(function (el, i) {
        el.classList.add('pd-reveal');
        el.style.setProperty('--pd-delay', Math.min(i, 8) * 70 + 'ms');
      });
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-in');
            io.unobserve(entry.target);
          }
        });
      }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
      targets.forEach(function (el) { io.observe(el); });
    }

    /* ----------------------------------------------------------------
       Angka statistik menghitung naik saat pertama tampil
       ---------------------------------------------------------------- */
    document.querySelectorAll('.pd-stat-value').forEach(function (el) {
      var target = parseInt(el.textContent.replace(/\D/g, ''), 10);
      if (isNaN(target) || reduceMotion) { return; }
      var start = null;
      var dur = 900;
      el.textContent = '0';
      function step(ts) {
        if (start === null) { start = ts; }
        var p = Math.min((ts - start) / dur, 1);
        el.textContent = Math.round(target * (1 - Math.pow(1 - p, 3))).toString();
        if (p < 1) { requestAnimationFrame(step); }
      }
      requestAnimationFrame(step);
    });

    /* ----------------------------------------------------------------
       Maskot NYX: gelembung tips yang berganti-ganti
       ---------------------------------------------------------------- */
    var dock = document.querySelector('.pd-mascot-dock');
    if (dock) {
      var bubble = dock.querySelector('.pd-mascot-bubble');
      var tips = [
        'Ketik di kolom pencarian atas untuk menyaring tabel halaman ini secara langsung.',
        'Tombol bulan/matahari di topbar mengganti mode gelap dan terang.',
        'Laporan peminjaman bisa langsung dicetak dari menu Laporan.',
        'Klik saya lagi kalau butuh pengingat lain.'
      ];
      var idx = 0;

      function showTip() {
        if (!bubble) { return; }
        bubble.innerHTML = '<b>NYX //</b> ' + tips[idx % tips.length];
        idx++;
        bubble.classList.add('is-visible');
        clearTimeout(bubble._t);
        bubble._t = setTimeout(function () { bubble.classList.remove('is-visible'); }, 6000);
      }

      dock.addEventListener('click', showTip);
      dock.addEventListener('mouseenter', showTip);
      setTimeout(showTip, 1800);
    }

    /* ----------------------------------------------------------------
       Pencarian tabel live (tetap seperti sebelumnya)
       ---------------------------------------------------------------- */
    var searchInput = document.getElementById('pdSearchInput');
    if (!searchInput) { return; }

    var tables = document.querySelectorAll('#layoutSidenav_content main table.table');

    searchInput.addEventListener('input', function () {
      var term = searchInput.value.trim().toLowerCase();

      tables.forEach(function (table) {
        var rows = table.querySelectorAll('tr');
        var visibleCount = 0;
        var headerCols = 0;

        rows.forEach(function (row) {
          if (row.classList.contains('pd-no-results')) { return; }
          if (row.querySelector('th')) {
            headerCols = row.children.length;
            return; // baris header tidak pernah disembunyikan
          }
          var text = row.textContent.toLowerCase();
          var matches = term === '' || text.indexOf(term) !== -1;
          row.style.display = matches ? '' : 'none';
          if (matches) { visibleCount++; }
        });

        var emptyRow = table.querySelector('.pd-no-results');
        if (visibleCount === 0 && term !== '') {
          if (!emptyRow) {
            emptyRow = document.createElement('tr');
            emptyRow.className = 'pd-no-results';
            var td = document.createElement('td');
            td.colSpan = headerCols || 1;
            td.textContent = 'Tidak ada data yang cocok dengan pencarian';
            emptyRow.appendChild(td);
            table.appendChild(emptyRow);
          }
          emptyRow.style.display = '';
        } else if (emptyRow) {
          emptyRow.style.display = 'none';
        }
      });
    });
  });
})();
