<div class="pd-page-title">Ubah Kategori Buku</div>
<div class="pd-page-sub">Perbarui nama kategori di bawah ini.</div>
<div class="card">
    <div class="card-body">
        <?php
        $id = intval($_GET['id']);
        if (isset($_POST['submit'])) {
            $kategori = mysqli_real_escape_string($koneksi, $_POST['kategori']);
            $query = mysqli_query($koneksi, "UPDATE kategori SET kategori='$kategori' WHERE id_kategori='$id'");
            if ($query) {
                echo '<script>alert("Ubah data berhasil!"); location.href="?page=kategori";</script>';
            } else {
                echo '<script>alert("Ubah data gagal!");</script>';
            }
        }
        $query = mysqli_query($koneksi, "SELECT * FROM kategori WHERE id_kategori='$id'");
        $data = mysqli_fetch_array($query);
        ?>
        <form method="post">
            <div class="pd-form-row" style="max-width:480px;">
                <label class="pd-form-label">Nama Kategori</label>
                <input type="text" class="form-control" value="<?php echo htmlspecialchars($data['kategori']); ?>" name="kategori" required>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary" name="submit" value="submit">Simpan</button>
                <a href="?page=kategori" class="btn btn-danger">Kembali</a>
            </div>
        </form>
    </div>
</div>
