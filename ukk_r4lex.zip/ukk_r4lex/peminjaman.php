<div class="pd-page-head">
    <div>
        <div class="pd-page-title">Peminjaman Buku</div>
        <div class="pd-page-sub">Riwayat dan status peminjaman bukumu.</div>
    </div>
    <a href="?page=peminjaman_tambah" class="btn btn-primary"><i class="fas fa-plus me-1"></i> Tambah Peminjaman</a>
</div>
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
        <table class="table" width="100%">
            <tr>
                <th>No</th>
                <th>User</th>
                <th>Buku</th>
                <th>Tanggal Pinjam</th>
                <th>Tanggal Kembali</th>
                <th>Status</th>
                <th class="text-end pe-4">Aksi</th>
            </tr>
            <?php
            $i = 1;
            $id_user = intval($_SESSION['user']['id_user']);
            $query = mysqli_query($koneksi, "SELECT * FROM peminjaman LEFT JOIN user ON user.id_user = peminjaman.id_user LEFT JOIN buku ON buku.id_buku = peminjaman.id_buku WHERE peminjaman.id_user='$id_user'");
            while ($data = mysqli_fetch_array($query)) {
            ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo htmlspecialchars($data['nama']); ?></td>
                    <td class="fw-semibold"><?php echo htmlspecialchars($data['judul']); ?></td>
                    <td><?php echo htmlspecialchars($data['tanggal_peminjaman']); ?></td>
                    <td><?php echo htmlspecialchars($data['tanggal_pengembalian']); ?></td>
                    <td>
                        <?php if ($data['status_peminjaman'] == 'dikembalikan') { ?>
                            <span class="pd-badge pd-badge-green">Dikembalikan</span>
                        <?php } else { ?>
                            <span class="pd-badge pd-badge-orange">Dipinjam</span>
                        <?php } ?>
                    </td>
                    <td class="text-end pe-4 text-nowrap">
                        <?php if ($data['status_peminjaman'] != 'dikembalikan') { ?>
                            <a href="?page=peminjaman_ubah&id=<?php echo $data['id_peminjaman']; ?>" class="btn btn-info btn-sm">Ubah</a>
                            <a onclick="return confirm('Apakah anda yakin hapus peminjaman ini?');" href="?page=peminjaman_hapus&id=<?php echo $data['id_peminjaman']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
        </div>
    </div>
</div>
