<?php
include "koneksi.php";

$error = '';
$success = '';

if (isset($_POST['register'])) {
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $alamat = trim($_POST['alamat']);
    $no_telepon = trim($_POST['no_telepon']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $level = 'peminjam'; // Registrasi publik selalu dibuat sebagai peminjam.
    // (Sebelumnya level bisa dipilih bebas termasuk "admin" lewat form publik —
    // ini celah keamanan dan sudah diperbaiki.)

    if ($nama === '' || $email === '' || $username === '' || $password === '') {
        $error = 'Semua data wajib diisi.';
    } else {
        $cek = mysqli_prepare($koneksi, "SELECT id_user FROM user WHERE username = ? LIMIT 1");
        mysqli_stmt_bind_param($cek, "s", $username);
        mysqli_stmt_execute($cek);
        mysqli_stmt_store_result($cek);

        if (mysqli_stmt_num_rows($cek) > 0) {
            $error = 'Username sudah digunakan, silakan pilih username lain.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($koneksi, "INSERT INTO user(nama, email, alamat, no_telepon, username, password, level) VALUES (?, ?, ?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "sssssss", $nama, $email, $alamat, $no_telepon, $username, $hash, $level);

            if (mysqli_stmt_execute($stmt)) {
                $success = 'Registrasi berhasil! Silakan login.';
            } else {
                $error = 'Registrasi gagal, silakan ulangi.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Register - Pustaka Digital</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@400;500;600;700&family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet" />
    <link href="css/theme.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <script>
        // Pasang tema sedini mungkin supaya tidak ada kedipan warna saat halaman dimuat.
        (function () {
            var t = localStorage.getItem('pd-theme') || 'dark';
            document.documentElement.classList.add(t === 'light' ? 'pd-pre-light' : 'pd-pre-dark');
            document.addEventListener('DOMContentLoaded', function () {
                document.body.classList.add(t === 'light' ? 'pd-light' : 'pd-dark');
            });
        })();
    </script>
</head>
<body>
    <div class="pd-auth-wrap">
        <div class="pd-auth-card" style="max-width:1020px;">
            <div class="pd-auth-visual">
                <div class="pd-auth-icon"><i class="fas fa-user-plus"></i></div>
                <h2>Daftarkan Diri di<br>Neo Archive</h2>
                <p>Buat akun peminjam untuk mulai meminjam buku, memberi ulasan, dan menjelajahi koleksi perpustakaan.</p>
                <div class="pd-auth-meta">Akun baru &middot; akses level peminjam</div>
                <div class="pd-mascot pd-auth-mascot">
                    <img src="assets/img/mascot-nyx.svg" alt="NYX, maskot operator arsip" />
                </div>
            </div>
            <div class="pd-auth-form">
                <h3>Daftar Akun</h3>
                <div class="pd-auth-sub">Registrasi pengguna baru</div>

                <?php if ($error) { ?>
                    <div class="pd-auth-error"><?php echo htmlspecialchars($error); ?></div>
                <?php } ?>
                <?php if ($success) { ?>
                    <div class="pd-auth-success"><?php echo htmlspecialchars($success); ?> <a href="login.php" style="color:var(--pd-accent-green);font-weight:700;">Login sekarang &rarr;</a></div>
                <?php } ?>

                <?php if (!$success) { ?>
                <form method="post">
                    <div class="row">
                        <div class="col-md-6 pd-form-row">
                            <label class="pd-form-label">Nama Lengkap</label>
                            <input class="form-control" name="nama" type="text" placeholder="Nama lengkap" required value="<?php echo isset($nama) ? htmlspecialchars($nama) : ''; ?>" />
                        </div>
                        <div class="col-md-6 pd-form-row">
                            <label class="pd-form-label">Email</label>
                            <input class="form-control" name="email" type="email" placeholder="Alamat email" required value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>" />
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 pd-form-row">
                            <label class="pd-form-label">No. Telepon</label>
                            <input class="form-control" name="no_telepon" type="text" placeholder="No telepon" required value="<?php echo isset($no_telepon) ? htmlspecialchars($no_telepon) : ''; ?>" />
                        </div>
                        <div class="col-md-6 pd-form-row">
                            <label class="pd-form-label">Username</label>
                            <input class="form-control" name="username" type="text" placeholder="Username" required value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>" />
                        </div>
                    </div>
                    <div class="pd-form-row">
                        <label class="pd-form-label">Alamat</label>
                        <textarea name="alamat" rows="2" class="form-control" required><?php echo isset($alamat) ? htmlspecialchars($alamat) : ''; ?></textarea>
                    </div>
                    <div class="pd-form-row">
                        <label class="pd-form-label">Password</label>
                        <input class="form-control" name="password" type="password" placeholder="Buat password" required />
                    </div>
                    <button class="btn btn-primary w-100 mt-2" type="submit" name="register" value="register">Daftar</button>
                </form>
                <div class="text-center mt-3" style="font-size:0.88rem;color:var(--pd-text-muted);">
                    Sudah punya akun? <a href="login.php" style="color:var(--pd-cyan);font-weight:600;">Login di sini</a>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <script src="js/theme.js"></script>
</body>
</html>
