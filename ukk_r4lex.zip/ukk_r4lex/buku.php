<div class="pd-page-head">
    <div>
        <div class="pd-page-title">Buku</div>
        <div class="pd-page-sub">Daftar seluruh koleksi buku perpustakaan.</div>
    </div>
    <a href="?page=buku_tambah" class="btn btn-primary"><i class="fas fa-plus me-1"></i> Tambah Buku</a>
</div>
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
        <table class="table" width="100%">
            <tr>
                <th>No</th>
                <th>Kategori</th>
                <th>Judul</th>
                <th>Penulis</th>
                <th>Penerbit</th>
                <th>Tahun</th>
                <th>Deskripsi</th>
                <th class="text-end pe-4">Aksi</th>
            </tr>
            <?php
            $i = 1;
            $query = mysqli_query($koneksi, "SELECT * FROM buku LEFT JOIN kategori ON buku.id_kategori = kategori.id_kategori");
            while ($data = mysqli_fetch_array($query)) {
            ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><span class="pd-badge pd-badge-purple"><?php echo htmlspecialchars($data['kategori']); ?></span></td>
                    <td class="fw-semibold"><?php echo htmlspecialchars($data['judul']); ?></td>
                    <td><?php echo htmlspecialchars($data['penulis']); ?></td>
                    <td><?php echo htmlspecialchars($data['penerbit']); ?></td>
                    <td><?php echo htmlspecialchars($data['tahun_terbit']); ?></td>
                    <td style="max-width:220px;" class="text-truncate"><?php echo htmlspecialchars($data['deskripsi']); ?></td>
                    <td class="text-end pe-4 text-nowrap">
                        <a href="?page=buku_ubah&id=<?php echo $data['id_buku']; ?>" class="btn btn-info btn-sm">Ubah</a>
                        <a onclick="return confirm('Apakah Anda yakin?');" href="?page=buku_hapus&id=<?php echo $data['id_buku']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
        </div>
    </div>
</div>
