<div class="pd-page-title">Ubah Ulasan Buku</div>
<div class="pd-page-sub">Perbarui isi ulasan atau rating.</div>
<div class="card">
    <div class="card-body">
        <?php
        $id = intval($_GET['id']);
        if (isset($_POST['submit'])) {
            $id_buku = intval($_POST['id_buku']);
            $ulasan = mysqli_real_escape_string($koneksi, $_POST['ulasan']);
            $rating = intval($_POST['rating']);

            $query = mysqli_query($koneksi, "UPDATE ulasan SET id_buku='$id_buku', ulasan='$ulasan', rating='$rating' WHERE id_ulasan='$id'");
            if ($query) {
                echo '<script>alert("Ubah ulasan berhasil!"); location.href="?page=ulasan";</script>';
            }
        }

        $q = mysqli_query($koneksi, "SELECT * FROM ulasan WHERE id_ulasan='$id'");
        $data = mysqli_fetch_array($q);
        ?>
        <form method="post">
            <div class="pd-form-row" style="max-width:480px;">
                <label class="pd-form-label">Buku</label>
                <select name="id_buku" class="form-select" required>
                    <?php
                    $b = mysqli_query($koneksi, "SELECT * FROM buku");
                    while ($book = mysqli_fetch_array($b)) {
                        $selected = ($data['id_buku'] == $book['id_buku']) ? 'selected' : '';
                        echo '<option value="' . $book['id_buku'] . '" ' . $selected . '>' . htmlspecialchars($book['judul']) . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="pd-form-row">
                <label class="pd-form-label">Ulasan</label>
                <textarea name="ulasan" rows="4" class="form-control" required><?php echo htmlspecialchars($data['ulasan']); ?></textarea>
            </div>
            <div class="pd-form-row" style="max-width:220px;">
                <label class="pd-form-label">Rating</label>
                <select name="rating" class="form-select">
                    <?php for ($i = 1; $i <= 10; $i++) {
                        $sel = ($data['rating'] == $i) ? 'selected' : '';
                        echo "<option value='$i' $sel>$i</option>";
                    } ?>
                </select>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
                <a href="?page=ulasan" class="btn btn-danger">Kembali</a>
            </div>
        </form>
    </div>
</div>
