<div class="pd-page-title">Tambah Peminjaman Buku</div>
<div class="pd-page-sub">Catat peminjaman buku baru.</div>
<div class="card">
    <div class="card-body">
        <?php
        if (isset($_POST['submit'])) {
            $id_buku = intval($_POST['id_buku']);
            $id_user = intval($_SESSION['user']['id_user']);
            $tanggal_peminjaman = $_POST['tanggal_peminjaman'];
            $tanggal_pengembalian = $_POST['tanggal_pengembalian'];
            $status_peminjaman = mysqli_real_escape_string($koneksi, $_POST['status_peminjaman']);

            $query = mysqli_query($koneksi, "INSERT INTO peminjaman(id_buku, id_user, tanggal_peminjaman, tanggal_pengembalian, status_peminjaman) VALUES('$id_buku', '$id_user', '$tanggal_peminjaman', '$tanggal_pengembalian', '$status_peminjaman')");
            if ($query) {
                echo '<script>alert("Tambah peminjaman berhasil!"); location.href="?page=peminjaman";</script>';
            }
        }
        ?>
        <form method="post">
            <div class="pd-form-row" style="max-width:480px;">
                <label class="pd-form-label">Buku</label>
                <select name="id_buku" class="form-select" required>
                    <?php
                    $b = mysqli_query($koneksi, "SELECT * FROM buku");
                    while ($book = mysqli_fetch_array($b)) {
                        echo '<option value="' . $book['id_buku'] . '">' . htmlspecialchars($book['judul']) . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="row">
                <div class="col-md-6 pd-form-row">
                    <label class="pd-form-label">Tanggal Pinjam</label>
                    <input type="date" class="form-control" name="tanggal_peminjaman" required>
                </div>
                <div class="col-md-6 pd-form-row">
                    <label class="pd-form-label">Tanggal Kembali</label>
                    <input type="date" class="form-control" name="tanggal_pengembalian" required>
                </div>
            </div>
            <div class="pd-form-row" style="max-width:300px;">
                <label class="pd-form-label">Status</label>
                <select name="status_peminjaman" class="form-select" required>
                    <option value="dipinjam">Dipinjam</option>
                    <option value="dikembalikan">Dikembalikan</option>
                </select>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
                <a href="?page=peminjaman" class="btn btn-danger">Kembali</a>
            </div>
        </form>
    </div>
</div>
