<?php
$id = $_GET['id'];
$query = mysqli_query($koneksi, "DELETE FROM ulasan WHERE id_ulasan='$id'");
if ($query) {
    echo '<script>alert("Hapus data berhasil!"); location.href="?page=ulasan";</script>';
}
?>