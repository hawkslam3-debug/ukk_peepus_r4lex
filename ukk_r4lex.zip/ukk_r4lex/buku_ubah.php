<div class="pd-page-title">Ubah Buku</div>
<div class="pd-page-sub">Perbarui detail buku di bawah ini.</div>
<div class="card">
    <div class="card-body">
        <?php
        $id = intval($_GET['id']);
        if (isset($_POST['submit'])) {
            $id_kategori = intval($_POST['id_kategori']);
            $judul = mysqli_real_escape_string($koneksi, $_POST['judul']);
            $penulis = mysqli_real_escape_string($koneksi, $_POST['penulis']);
            $penerbit = mysqli_real_escape_string($koneksi, $_POST['penerbit']);
            $tahun_terbit = intval($_POST['tahun_terbit']);
            $deskripsi = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);

            $query = mysqli_query($koneksi, "UPDATE buku SET id_kategori='$id_kategori', judul='$judul', penulis='$penulis', penerbit='$penerbit', tahun_terbit='$tahun_terbit', deskripsi='$deskripsi' WHERE id_buku='$id'");
            if ($query) {
                echo '<script>alert("Ubah buku berhasil!"); location.href="?page=buku";</script>';
            }
        }

        $buku = mysqli_query($koneksi, "SELECT * FROM buku WHERE id_buku='$id'");
        $data = mysqli_fetch_array($buku);
        ?>
        <form method="post">
            <div class="row">
                <div class="col-md-6 pd-form-row">
                    <label class="pd-form-label">Kategori</label>
                    <select name="id_kategori" class="form-select" required>
                        <?php
                        $kat = mysqli_query($koneksi, "SELECT * FROM kategori");
                        while ($k = mysqli_fetch_array($kat)) {
                            $selected = ($data['id_kategori'] == $k['id_kategori']) ? 'selected' : '';
                            echo '<option value="' . $k['id_kategori'] . '" ' . $selected . '>' . htmlspecialchars($k['kategori']) . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-6 pd-form-row">
                    <label class="pd-form-label">Judul</label>
                    <input type="text" class="form-control" name="judul" value="<?php echo htmlspecialchars($data['judul']); ?>" required>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 pd-form-row">
                    <label class="pd-form-label">Penulis</label>
                    <input type="text" class="form-control" name="penulis" value="<?php echo htmlspecialchars($data['penulis']); ?>" required>
                </div>
                <div class="col-md-6 pd-form-row">
                    <label class="pd-form-label">Penerbit</label>
                    <input type="text" class="form-control" name="penerbit" value="<?php echo htmlspecialchars($data['penerbit']); ?>" required>
                </div>
            </div>
            <div class="pd-form-row" style="max-width:220px;">
                <label class="pd-form-label">Tahun Terbit</label>
                <input type="number" class="form-control" name="tahun_terbit" value="<?php echo htmlspecialchars($data['tahun_terbit']); ?>" required>
            </div>
            <div class="pd-form-row">
                <label class="pd-form-label">Deskripsi</label>
                <textarea name="deskripsi" class="form-control" rows="4" required><?php echo htmlspecialchars($data['deskripsi']); ?></textarea>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
                <a href="?page=buku" class="btn btn-danger">Kembali</a>
            </div>
        </form>
    </div>
</div>
